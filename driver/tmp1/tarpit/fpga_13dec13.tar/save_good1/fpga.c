/***********************************************************
*
* Code to write/read FPGA file to CAEN1495 on the Linux VME frontend
* R. Michaels   Dec 2013
* This version only writes to USER FPGA.
*
*/

#include <string.h>
#include <stdio.h>
#include "v1495.h"

int main(int argc, char *argv[]) {

  printf("About to write FPGA file \n");

  /* Intel PC version:  do NOT want fa520000, only 520000 */

  v1495firmware(0x520000,"mlu.rbf",0,0);

  v1495initMlu(0x520000);

  exit(0);

}

